#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>

#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <queue.h>

#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"

#include "bitwise_operation.h"

#define LOCK_PASSWORD 	      0x4C4F434B

#define CONTROL_PORT 					GPIO_PORTF_BASE 
#define OBSTACLE_SWITCH 			GPIO_PIN_0
#define LOCK_TOGGLE						GPIO_PIN_4

#define OBSTACLE_SWITCH_NUM 	0	
#define LOCK_TOGGLE_NUM				4	

#define MOTOR_PORT						GPIO_PORTD_BASE	
#define MOTOR_IN1							GPIO_PIN_2
#define MOTOR_IN2							GPIO_PIN_3

#define MOTOR_IN1_NUM					2
#define MOTOR_IN2_NUM					3

#define LIMIT_PORT						GPIO_PORTE_BASE
#define LIMIT_UP							GPIO_PIN_1
#define LIMIT_DOWN						GPIO_PIN_2

#define LIMIT_UP_NUM					1	
#define LIMIT_DOWN_NUM				2	

#define DRIVER_PORT						GPIO_PORTB_BASE	
#define DRIVER_UP							GPIO_PIN_0	
#define DRIVER_DOWN						GPIO_PIN_1	

#define DRIVER_UP_NUM					0	
#define DRIVER_DOWN_NUM				1	

#define PASSENGER_PORT				GPIO_PORTA_BASE	
#define PASSENGER_UP					GPIO_PIN_6	
#define PASSENGER_DOWN				GPIO_PIN_7	

#define PASSENGER_UP_NUM			6	
#define PASSENGER_DOWN_NUM		7	


typedef enum 
{ 
    STOP, MANUAL_UP, MANUAL_DOWN ,AUTO_DOWN , AUTO_UP
} MotorState;

uint8_t automaticControlDisabled = 0, down_f = 0 , up_f = 0; //Flags to be used mid operation to ensure right execution.
unsigned autosw = 0;

/*==================================================Function Prototypes and Task Definitions and ISR Prototypes======================================*/
#warning Tasks and Isr
void driverSide_ISR (void);	//ISR For Driver side pushbuttons for when pressed and interrupt is triggered.
void driverWindowUp_TASK (void *ptr);  //Task For driver up pushbutton for when pressed, the window either moves up automatically or manually. 
void driverWindowDown_TASK (void *ptr);  //Task For driver up pushbutton for when pressed, the window either moves down automatically or manually.
void passengerSide_ISR (void);  //ISR For Passenger side pushbuttons for when pressed and interrupt is triggered.
void passengerWindowUp_TASK (void *ptr);  //Task For passenger up pushbutton for when pressed, the window either moves up automatically or manually.
void passengerWindowDown_TASK (void *ptr);  //Task For passenger down pushbutton for when pressed, the window either moves up automatically or manually.
void motorMove_TASK (void *ptr);  //Task Responsible for movement of motor based on the direction decided by the previous.
void lockWindow_TASK (void *ptr); //Task For setting that the window is to be locked from the passenger and driver sides.
void jam_TASK (void *ptr); //Task For obstacle detection. 
void limitSwitch_ISR (void); //ISR for the limit switches to give semaphore to the limit Task.
void limitSwitch_TASK (void *ptr); //Task for the limit switch pressing.
void initGpio (void); //Set all the pins that will be used as well as the interrupts.

#warning IdleHook
void vApplicationIdleHook( void ); //idle task to be used to sleep the ECU in case of no interrupts therefore no tasks are being carried out.

/*===================================================Semaphores creation and Mutex======================================================================*/
#warning Semaphores
xSemaphoreHandle xUpDriverSemaphore; //Semaphore to be given or taken in case the driver window up button is pressed.
xSemaphoreHandle xDownDriverSemaphore; //Semaphore to be given or taken in case the driver window down button is pressed.
xSemaphoreHandle xUpPassengerSemaphore; //Semaphore to be given or taken in case the Passenger window up button is pressed.
xSemaphoreHandle xDownPassengerSemaphore; //Semaphore to be given or taken in case the Passenger window up button is pressed.
xSemaphoreHandle xLockSemaphore; //Semaphore to be given or taken in case the Lock button is pressed.
xSemaphoreHandle xJamSemaphore; //Semaphore to be given or taken in case the Obstacle button is pressed.
xSemaphoreHandle xLimitSwitchSemaphore; //Semaphore to be given or taken in case the Limit switch is pressed.


//=============================================================Mutex===================================================================
#warning Mutex
xSemaphoreHandle xMotorStateMutex; //mutex for motor to prevent other tasks from executing if a task has the motor mutex.


/*========================================================Queue Creation==============================================================*/
#warning Queue
xQueueHandle xMotorStateQueue; //Queue to send and recieve the status of the motor to be later controlled by the motor Decision task.


//=========================================================Main Section=================================================================
#warning Main
int main()
{
	xMotorStateQueue = xQueueCreate( 10, sizeof( MotorState ) ); //Create the queue of length 10 and type status of motor which is a predefined enum.
	xMotorStateMutex = xSemaphoreCreateMutex(); //Create a mutex for motor to be used in order to prevent multiple tasks altering the status together.
	
	vSemaphoreCreateBinary( xUpDriverSemaphore ); //Semaphore to be given or taken in case the driver window up button is pressed.
	vSemaphoreCreateBinary( xDownDriverSemaphore ); //Semaphore to be given or taken in case the driver window down button is pressed.
	vSemaphoreCreateBinary( xUpPassengerSemaphore ); //Semaphore to be given or taken in case the Passenger window up button is pressed.
	vSemaphoreCreateBinary( xDownPassengerSemaphore ); //Semaphore to be given or taken in case the Passenger window down button is pressed.
	vSemaphoreCreateBinary( xLockSemaphore ); //Semaphore to be given or taken in case the lock button is pressed.
	vSemaphoreCreateBinary( xJamSemaphore ); //Semaphore to be given or taken in case the obstacle button is pressed.
	vSemaphoreCreateBinary( xLimitSwitchSemaphore ); //Semaphore to be given or taken in case the Limit switch is pressed.
	
	initGpio(); //Call initGpio function to make sure that all pins are ready to be used.
	
	
//=====================================================Tasks Creation=================================================================
	xTaskCreate (driverWindowUp_TASK , "Driver Up" , 200 , NULL , 1 , NULL); //Create D up task and set priority to 1.
	xTaskCreate (limitSwitch_TASK, "Task for Limit Switch" , 200 , NULL , 2 , NULL); //Create Limit task and set priority to 2.
	xTaskCreate (motorMove_TASK , "MotorMove" , 200 , NULL , 1 , NULL); //Create Motor Decision task and set priority to 1.
	xTaskCreate (jam_TASK , "Jam" , 200 , NULL , 3 , NULL); //Create Jam task and set priority to 3.
	xTaskCreate (lockWindow_TASK , "Lock" , 200 , NULL , 4 , NULL); //Create Lock task and set priority to 4.
	xTaskCreate (driverWindowDown_TASK , "Driver Down" , 200 , NULL , 1 , NULL); //Create D down task and set priority to 1.	
	xTaskCreate (passengerWindowUp_TASK , "Passenger Up" , 200, NULL , 1 , NULL); //Create P up task and set priority to 1.
	xTaskCreate (passengerWindowDown_TASK , "Passenger Down" , 200 , NULL , 1 , NULL); //Create P down task and set priority to 1.
	
	vTaskStartScheduler();

	for (;;);
	
}


//=========================================================Driver side ISR==============================================================
void driverSide_ISR (void) //ISR for Driver side to Give semaphore to either the driver window upwards or downwards once the button is pressed.
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE; //To be changed if task priority is higher than the current task to force context switching.
	if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT,DRIVER_UP) , DRIVER_UP_NUM) ) //Check if up button is pressed or not to determine which task semaphore will be given.
	{

		xSemaphoreGiveFromISR( xUpDriverSemaphore, &xHigherPriorityTaskWoken); //Give semaphore to driver up task.
		GPIOIntClear(DRIVER_PORT, DRIVER_UP); //Clear interrupt flag of the driver up pin.

	}
	
	else if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT,DRIVER_DOWN) , DRIVER_DOWN_NUM) )//Check if down button is pressed or not to determine which task semaphore will be given.
	{

		xSemaphoreGiveFromISR( xDownDriverSemaphore, &xHigherPriorityTaskWoken); //Give semaphore to the driver down task
		GPIOIntClear(DRIVER_PORT, DRIVER_DOWN); //Clear interrup flag of the driver down pin		

	}
	
	//Clearing again for assurance.
	GPIOIntClear(DRIVER_PORT, DRIVER_UP);//Clear interrupt flag of the driver up pin.
	GPIOIntClear(DRIVER_PORT, DRIVER_DOWN);//Clear interrupt flag of the driver down pin.
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken ); //Force a context switch if the task granted semaphore is of higher priority.
}


//========================================================Driver window upwards Task====================================================
void driverWindowUp_TASK (void *ptr) //This task is responsible for the upward motion of the window from the driver's side.
{
	MotorState stateOfMotor = STOP; //Set inital MotorState to stopped as we're going to change that later from the queue
	uint8_t  queueSentUp = 0 , automaticModeUpOn = 0 , semaphoreReceived = 0; //Reset all vars before entering task
	
	for(;;)
	{
		if (semaphoreReceived == 0) //check whether if the semaphore for the upwards motion was recieved or not, if not recieve it or get blocked for portMAX_DELAY, Recieve also the motor mutex to prevent the alteration of that from another task.
		{
			xSemaphoreTake( xUpDriverSemaphore, portMAX_DELAY ); //Take the semaphore for the driver up task, if not get blocked as the interrupt wasn't triggered yet
			xSemaphoreTake( xMotorStateMutex, portMAX_DELAY ); //Take the mutex for the motor controlling, if not that means another task is altering the motor therefore get blocked until available again.
			semaphoreReceived = 1; //set semaphore flag to 1 in order to continue task execution in the next loop.
		}
		else
		{
		if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT,DRIVER_UP) , DRIVER_UP_NUM) ) //check whether if the driver up button is pressed.
		{
			vTaskDelay( 30/portTICK_RATE_MS); //for debounce.
			if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT,DRIVER_UP) , DRIVER_UP_NUM) ) //check whether if the driver up button is pressed.
			{
				if (queueSentUp == 0) //if the flag is set to one that means that it's already going upwards so there's no need to execute this.
				{
					up_f = 1;
					stateOfMotor = MANUAL_UP; //Set MotorState to up to be sent to the queue.
					xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState of the motor to the queue.
					queueSentUp = 1; //Set Driver flag to 1 to indicate upwards motion of the window.
					automaticModeUpOn = 1; //set MotorState to be used later if needed in automatic motion.
					
					vTaskDelay( 1000/portTICK_RATE_MS); //Delay task for a second in order to give user the time to either go manual or automatic.
				}
				else 
				{
					automaticModeUpOn = 0; //will continue executing as long as the button isn't released , prevent from entering automatic mode.
				}
			}
		}
		else if( ( BIT_IS_SET(GPIOPinRead(DRIVER_PORT,DRIVER_UP) , DRIVER_UP_NUM) ) &&  automaticModeUpOn ) //if the button isn't pressed that means that the user will go automatic mode as the previous MotorState was up.
		{
			stateOfMotor = AUTO_UP; //set MotorState to be sent as auto up and send it later to the queue.
			automaticModeUpOn = 0; //set previous MotorState to 0 in order to prevent entering this 
			queueSentUp = 0; //set Driver up flag to zero as the task will be blocked eventually so reset all vars.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to auto move motor.
			xSemaphoreGive(xMotorStateMutex);//Give mutex in order to let other tasks modify the MotorState of the motor
		}
		else //This is added specially for the manual mode to stop motor once the button is released.
		{
			stateOfMotor = STOP; //set MotorState to stop and send it in the queue.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			queueSentUp = 0; //set Driver up flag to zero as now the up is stopped and we're resetting the flag.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to stop motor.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor
		}			
	}
}
}


//======================================================Driver Down task===============================================================
void driverWindowDown_TASK (void *ptr) //This task is responsible for the downward motion of the window from the driver's side.
{
	MotorState stateOfMotor = STOP; //Set inital MotorState to stopped as we're going to change that later from the queue.
	uint8_t queueSentDown = 0 , automaticModeDownOn = 0 , semaphoreReceived = 0; //Reset all vars before entering task.
	
	for(;;)
	{
		if (semaphoreReceived == 0) //check whether if the semaphore for the downwards motion was recieved or not, if not recieve it or get blocked for portMAX_DELAY, Recieve also the motor mutex to prevent the alteration of that from another task.
		{
			xSemaphoreTake( xDownDriverSemaphore, portMAX_DELAY ); //Take the semaphore for the driver up task, if not get blocked as the interrupt wasn't triggered yet
			xSemaphoreTake( xMotorStateMutex, portMAX_DELAY ); //Take the mutex for the motor controlling, if not that means another task is altering the motor therefore get blocked until available again.
			semaphoreReceived = 1; //set semaphore flag to 1 in order to continue task execution in the next loop.
		}
		else
		{
		if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT,DRIVER_DOWN) , DRIVER_DOWN_NUM) ) //check whether if the driver down button is pressed.
		{
			vTaskDelay( 30/portTICK_RATE_MS); //Delay task for debounce.
			if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT,DRIVER_DOWN) , DRIVER_DOWN_NUM) ) //check whether if the driver down button is pressed.
			{
				if (queueSentDown == 0) //if the flag is set to one that means that it's already going downwards so there's no need to execute this.
				{
					down_f = 1;
					stateOfMotor = MANUAL_DOWN; //Set MotorState to down to be sent to the queue.
					xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState of the motor to the queue.
					queueSentDown = 1;  //Set Driver flag to 1 to point that the window is going downwards.

					automaticModeDownOn = 1; //set MotorState to be used later if needed in automatic motion.
					vTaskDelay( 1000/portTICK_RATE_MS); //Delay task for a second in order to give user the time to either go manual or automatic.
				}
				else 
				{
					automaticModeDownOn = 0; //will continue executing as long as the button isn't released , prevent from entering automatic mode.
				}
			}
		}
		else if( ( BIT_IS_SET(GPIOPinRead(DRIVER_PORT,DRIVER_DOWN) , DRIVER_DOWN_NUM) ) &&  automaticModeDownOn ) //if the button isn't pressed that means that the user will go automatic mode as the previous MotorState was up.
		{
			stateOfMotor = AUTO_DOWN; //set MotorState to be sent as auto up and send it later to the queue.
			automaticModeDownOn = 0; //set previous MotorState to 0 in order to prevent entering this.
			queueSentDown = 0; //set Driver down flag to zero as the task will be blocked eventually so reset all vars.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 );  //send MotorState in queue to auto move motor.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor.
		}
		else 
		{
			stateOfMotor = STOP; //set MotorState to stop and send it in the queue.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			queueSentDown = 0; //set Driver up flag to zero as now the up is stopped and we're resetting the flag.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to stop motor.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor
		}		
	}
}
}


//======================================================Passenger Side ISR==============================================================
void passengerSide_ISR (void) //ISR for Passenger side to Give semaphore to either the driver window upwards or downwards once the button is pressed.
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE; //To be used later either to force or stop context switching.
	if ( BIT_IS_CLEAR(GPIOPinRead(PASSENGER_PORT,PASSENGER_UP) , PASSENGER_UP_NUM) ) //Check whether if passenger up button is pressed or not.
	{

		xSemaphoreGiveFromISR( xUpPassengerSemaphore, &xHigherPriorityTaskWoken); //Give semaphore to the passenger up task to make it ready.
		GPIOIntClear(PASSENGER_PORT,PASSENGER_UP); //Clear interrupt flag from passenger up pin.
	}
	
	else if ( BIT_IS_CLEAR(GPIOPinRead(PASSENGER_PORT,PASSENGER_DOWN) , PASSENGER_DOWN_NUM) ) //Check whether if passenger down button is pressed or not.
	{

		xSemaphoreGiveFromISR( xDownPassengerSemaphore, &xHigherPriorityTaskWoken); //Give semaphore to the passenger down task to make it ready.
		GPIOIntClear(PASSENGER_PORT,PASSENGER_DOWN); //Clear interrupt flag from passenger down pin.	
	}
	GPIOIntClear(PASSENGER_PORT,PASSENGER_UP); //Clear interrupt again for assurance.
	GPIOIntClear(PASSENGER_PORT,PASSENGER_DOWN); //Clear interrupt again for assurance.
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken ); //Force context switching in case that the task ready is of higher priority.
}


//==================================================== Passenger Window Upwards Task ====================================================
void passengerWindowUp_TASK (void *ptr) //This task is responsible for the upward motion of the window from the Passenger's side.
{
	MotorState stateOfMotor = STOP; //Set inital MotorState to stopped as we're going to change that later from the queue
	uint8_t Passenger_flag_up = 0 , automaticModeUpOn = 0, semaphoreReceived = 0 ; //Reset all vars before entering task.	
	for(;;)
	{
		if (semaphoreReceived == 0) //check whether if the semaphore for the downwards motion was recieved or not, if not recieve it or get blocked for portMAX_DELAY, Recieve also the motor mutex to prevent the alteration of that from another task.
		{
			xSemaphoreTake( xUpPassengerSemaphore, portMAX_DELAY ); //Take the semaphore for the driver up task, if not get blocked as the interrupt wasn't triggered yet
			xSemaphoreTake( xMotorStateMutex, portMAX_DELAY ); //Take the mutex for the motor controlling, if not that means another task is altering the motor therefore get blocked until available again.
			semaphoreReceived = 1; //set semaphore flag to 1 in order to continue task execution in the next loop.
		}
		else
		{
		if ( BIT_IS_CLEAR(GPIOPinRead(PASSENGER_PORT,PASSENGER_UP) , PASSENGER_UP_NUM) ) //check whether if the Passenger up button is pressed.
		{
			vTaskDelay( 30/portTICK_RATE_MS); //Delay task for debounce.
			if ( BIT_IS_CLEAR(GPIOPinRead(PASSENGER_PORT,PASSENGER_UP) , PASSENGER_UP_NUM) ) //check whether if the Passenger Up button is pressed.
			{
				if (Passenger_flag_up == 0) //if the flag is set to one that means that it's already going upwards so there's no need to execute this.
				{
					up_f = 1;
					stateOfMotor = MANUAL_UP; //Set MotorState to MANUAL_UP to be sent to the queue.
					xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to move motor upwards manually.
					Passenger_flag_up = 1; //Set Driver flag to 1 to point that the window is going upwards.
					automaticModeUpOn = 1; //set MotorState to be used later if needed in automatic motion.
					vTaskDelay( 1000/portTICK_RATE_MS); //Delay task for a second in order to give user the time to either go manual or automatic.
				}
				else 
				{
					automaticModeUpOn = 0; //will continue executing as long as the button isn't released , prevent from entering automatic mode.
				}
			}
		}
		else if( ( BIT_IS_SET(GPIOPinRead(PASSENGER_PORT,PASSENGER_UP) , PASSENGER_UP_NUM) ) &&  automaticModeUpOn ) //if the button isn't pressed that means that the user will go automatic mode as the previous MotorState was up.
		{
			stateOfMotor = AUTO_UP; //Set MotorState to Automatic upwards to be sent to the queue.
			automaticModeUpOn = 0; //set previous MotorState to 0 in order to prevent entering this.
			semaphoreReceived = 0;  //set semaphore flag to zero as task will be blocked as the button is released.
			Passenger_flag_up = 0; //set Passenger up flag to zero as the task will be blocked eventually so reset all vars.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to move motor upwards automatically.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor
		}
		else 
		{
			Passenger_flag_up = 0;  //set Passenger up flag to zero as the task will be blocked eventually so reset all vars.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			stateOfMotor = STOP; //Set MotorState to stopped to be sent to the queue.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to stop motor.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor
		}		
	}
}
}


//========================================================== Passenger Window downwards Task ==================================================
void passengerWindowDown_TASK (void *ptr) //This task is responsible for the downward motion of the window from the Passenger's side.
{
	MotorState stateOfMotor = STOP; //Set inital MotorState to stopped as we're going to change that later from the queue
	uint8_t Passenger_flag_down = 0 , automaticModeDownOn = 0 , semaphoreReceived = 0; //Reset all vars before entering task.
	for(;;)
	{
		if (semaphoreReceived == 0) //check whether if the semaphore for the downwards motion was recieved or not, if not recieve it or get blocked for portMAX_DELAY, Recieve also the motor mutex to prevent the alteration of that from another task.
		{
			xSemaphoreTake( xDownPassengerSemaphore, portMAX_DELAY ); //Take the semaphore for the driver up task, if not get blocked as the interrupt wasn't triggered yet
			xSemaphoreTake( xMotorStateMutex, portMAX_DELAY ); //Take the mutex for the motor controlling, if not that means another task is altering the motor therefore get blocked until available again.
			semaphoreReceived = 1; //set semaphore flag to 1 in order to continue task execution in the next loop.
		}
		else
		{
		if ( BIT_IS_CLEAR(GPIOPinRead(PASSENGER_PORT, PASSENGER_DOWN) , PASSENGER_DOWN_NUM) ) //check whether if the Passenger down button is pressed.
		{
			vTaskDelay( 30/portTICK_RATE_MS); //Delay task for debounce.
			if ( BIT_IS_CLEAR(GPIOPinRead(DRIVER_PORT, PASSENGER_DOWN) , PASSENGER_DOWN_NUM) ) //check whether if the Passenger down button is pressed.
			{
				if (Passenger_flag_down == 0) //if the flag is set to one that means that it's already going downwards so there's no need to execute this.
				{
					down_f = 1;
					stateOfMotor = MANUAL_DOWN; //Set MotorState to down to be sent to the queue.
					xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to move motor downwards manually.
					Passenger_flag_down = 1; //Set Driver flag to 1 to point that the window is going downwards.

					automaticModeDownOn = 1; //set MotorState to be used later if needed in automatic motion.
					vTaskDelay( 1000/portTICK_RATE_MS); //Delay task for a second in order to give user the time to either go manual or automatic.
				}
				else 
				{
					automaticModeDownOn = 0; //will continue executing as long as the button isn't released , prevent from entering automatic mode.
				}
			}
		}
		else if( ( BIT_IS_SET(GPIOPinRead(PASSENGER_PORT,PASSENGER_DOWN) , PASSENGER_DOWN_NUM) ) &&  automaticModeDownOn ) //if the button isn't pressed that means that the user will go automatic mode as the previous MotorState was down.
		{
			stateOfMotor = AUTO_DOWN; //Set MotorState to automatic down to be sent to the queue.
			automaticModeDownOn = 0; //set previous MotorState to 0 in order to prevent entering this.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			Passenger_flag_down = 0;  //set Passenger down flag to zero as the task will be blocked eventually so reset all vars.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to move motor downwards automatically.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor
		}
		else 
		{
			stateOfMotor = STOP; //Set MotorState to stopped to be sent to the queue.
			Passenger_flag_down = 0;  //set Passenger down flag to zero as the task will be blocked eventually so reset all vars.
			semaphoreReceived = 0; //set semaphore flag to zero as task will be blocked as the button is released.
			xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //send MotorState in queue to stop.
			xSemaphoreGive(xMotorStateMutex); //Give mutex in order to let other tasks modify the MotorState of the motor
		}
	}
}
}


//===========================================================Motor Decision Task========================================================
void motorMove_TASK (void *ptr) //Motor Decision Task is responsible for the movement of the motor as desired whether if it's up or down or automatic or manual or Stop.
{ 
	portBASE_TYPE xStatus;
	MotorState stateOfMotor = STOP;
	for(;;)
	{
		xQueueReceive( xMotorStateQueue, &stateOfMotor, portMAX_DELAY ); //Recieve the MotorState of the motor from the queue, The MotorState should be sent from the tasks responsible for the upward or downward motion of the motor and either from the passenger or driver side
  
	if (stateOfMotor == STOP) //Incase  that the status of the motor recieved is stopped the motor will be stopped and that's it.
	{
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 ); //Stop Motor
	}
	else if ( stateOfMotor == MANUAL_DOWN ) //this should move motor down but firs't it checks on whether if limit switches are pressed or not in each case alone.
	{
		if ( BIT_IS_CLEAR(GPIOPinRead(LIMIT_PORT,LIMIT_DOWN) , LIMIT_DOWN_NUM) ) //incase of downward motion check whether if the downward limit switch is pressed, if yes then stop motor ,if not move motor
		{
			GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 ); //Stop motor
		}
		else
		{
		up_f = 0 ;
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , MOTOR_IN1 ); //Move motor.
		}
	}
	else if ( stateOfMotor == MANUAL_UP && automaticControlDisabled == 0 ) //this should move motor up but first it checks on whether if limit switches are pressed or not in each case alone.
	{
		if ( BIT_IS_CLEAR(GPIOPinRead(LIMIT_PORT,LIMIT_UP) , LIMIT_UP_NUM) ) //incase of upward motion check whether if the upward limit switch is pressed, if yes then stop motor ,if not move motor
		{
			GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 ); //Stop Motor
		}
		else 
		{
			down_f = 0 ;
			GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , MOTOR_IN2 ); //Move motor
		}
	}	
	else if ( stateOfMotor == AUTO_DOWN )  //this should move motor Down automatically but first it checks on whether if limit switches are pressed or not in each case alone, whether if the controlling flag is raised or not to detect automated motion.
	{
		while ( BIT_IS_SET(GPIOPinRead(LIMIT_PORT,LIMIT_DOWN) , LIMIT_DOWN_NUM) && automaticControlDisabled == 0 && up_f == 0)//incase of downward motion check whether if the downward limit switch is pressed, if yes then stop motor ,if not move motor, if control flag is raised therefore never enter this as it's manual
		{
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , MOTOR_IN1 ); //Move motor as long as we're automatic mode, limit switch isn't reading any.
		}
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 ); //Stop motor as the limit switch MotorState or mode has been altered
		automaticControlDisabled = 0;
		up_f = 0 ;
	}	
	else if ( stateOfMotor == AUTO_UP ) //this should move motor up automatically but first it checks on whether if limit switches are pressed or not in each case alone, whether if the controlling flag is raised or not to detect automated motion.
	{
		while ( BIT_IS_SET(GPIOPinRead(LIMIT_PORT,LIMIT_UP) , LIMIT_UP_NUM) && automaticControlDisabled == 0 && down_f == 0) //incase of upward motion check whether if the upward limit switch is pressed, if yes then stop motor ,if not move motor, if control flag is raised therefore never enter this as it's manual
		{
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , MOTOR_IN2 );  //Move motor as long as we're automatic mode, limit switch isn't reading any.
		}
		down_f = 0 ;
		automaticControlDisabled = 0;
	}	

} 
	
} 

//======================================================== Control ISR for Lock and obstacle ===========================================
void lockControl_ISR(void) //Control ISR is to grant Semaphore to the window jam or the lock tasks.
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE; //Will be used later to either force or prevent context switching tasks.
	
	if ( BIT_IS_CLEAR(GPIOPinRead(CONTROL_PORT,LOCK_TOGGLE) , LOCK_TOGGLE_NUM) ) //Check whether if the lock toggle is pressed or not.
	{
		automaticControlDisabled = 1; //Set control flag to 1, will be used in the automatic motion to prevent automatic motion in case of ISR triggering.
		xSemaphoreGiveFromISR( xLockSemaphore, &xHigherPriorityTaskWoken); //Give semaphore to lock task to operate.
		GPIOIntClear(CONTROL_PORT,LOCK_TOGGLE); //Clear interrupt.
	}
	else if( BIT_IS_CLEAR(GPIOPinRead(CONTROL_PORT,OBSTACLE_SWITCH) , OBSTACLE_SWITCH_NUM) ) //Check if the obstacle push button is pressed or not.
	{
		automaticControlDisabled = 1; //Set control flag to 1, will be used in the automatic motion to prevent automatic motion in case of ISR triggering.
		xSemaphoreGiveFromISR( xJamSemaphore , &xHigherPriorityTaskWoken); //Give semaphore to the obstacle task to operate.
		GPIOIntClear(CONTROL_PORT,OBSTACLE_SWITCH); //Clear interrupt.
	}
	GPIOIntClear(CONTROL_PORT,LOCK_TOGGLE); //Clear interrupt again for assurance.
	GPIOIntClear(CONTROL_PORT,OBSTACLE_SWITCH); //Clear interrupt again for assurance.
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken ); //To force context switching in case of higher priority task being ready.
}


//===================================================== Window lock Task ================================================================
void lockWindow_TASK (void *ptr) //Window lock Task for when the lock is pressed.
{
	MotorState stateOfMotor = STOP; //Set MotorState to stop as window lock will stop the motor.
	for(;;)
	{
		
		xSemaphoreTake(xLockSemaphore , portMAX_DELAY ); //Take semaphore from the isr in case triggered, if not the task will be blocked.
		xQueueReset( xMotorStateQueue ); //Reset queue to restart the operation once the lock is released
		xQueueSendToBack( xMotorStateQueue , &stateOfMotor, 0 ); //Send new status after the lock is initiated and motor is stopped
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 ); //Stop motor
		while ( BIT_IS_CLEAR(GPIOPinRead(CONTROL_PORT,LOCK_TOGGLE) , LOCK_TOGGLE_NUM) ) //Wait and get stuck in this loop as long as the button is latched.
		{
			__WFI(); //Sleep until an interrupt is recieved.
		}
		automaticControlDisabled = 0;
	}
}


//========================================================== Window Jam Task ================================================================
void jam_TASK (void *ptr) //jam_TASK to handle the jamming incase of the presence of an obstacle midway through the movement of the window.
{
	MotorState stateOfMotor = STOP;
	for(;;)
	{
		xSemaphoreTake(xJamSemaphore , portMAX_DELAY ); //Receive the semaphore from the obstacle ISR in order to work otherwise the task will be blocked
		xQueueReset( xMotorStateQueue );  //Reset Queue to restart the motion of the window from the beginning again.
		if ( BIT_IS_SET(GPIOPinRead(LIMIT_PORT,LIMIT_DOWN) , LIMIT_DOWN_NUM) ) // Incase the limit switch isn't pressed move down for 0.5 seconds then stop
		{
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , MOTOR_IN1 ); //Move motor down as the limit switch isn't pressed
		vTaskDelay (500/portTICK_RATE_MS); //Suspend task for 0.5 seconds to make correction movement.
		}
		else  // Incase the limit switch is pressed don' move just stop.
		{
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 );  //Stop motor and don't move down as the limit switch is pressed
		vTaskDelay (500/portTICK_RATE_MS);  //Suspend task for 0.5 seconds to make correction movement.
		}
		
		
		GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 );  //After the 0.5 seconds regardless of the limit switches just stop the motors
		automaticControlDisabled = 0;
	}
}


//=================================================== Limit Switch ISR =================================================================
void limitSwitch_ISR (void) //Limit switch ISR to be triggered once the limit switch is pressed
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE; //For forcing context switching in case a task of higher priority is ready.
	xSemaphoreGiveFromISR( xLimitSwitchSemaphore , &xHigherPriorityTaskWoken); //Give semaphore to the Limit switch task to stop the motor instantly.
	GPIOIntClear(LIMIT_PORT,LIMIT_UP); //Clear interrupt.
	GPIOIntClear(LIMIT_PORT,LIMIT_DOWN); //Clear interrupt.
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken ); //Force a context switch in case the task is ready and is of higher priority.
}

//================================================== Limit Switch Task =================================================================
void limitSwitch_TASK (void *ptr)
{
	for(;;)
	{
	xSemaphoreTake(xLimitSwitchSemaphore , portMAX_DELAY ); //Take semaphore from the ISR, if not taken the Task is blocked.
	xQueueReset( xMotorStateQueue ); //Reset Queue in order to restart operation all again as motor will stop.
	GPIOPinWrite(MOTOR_PORT , (MOTOR_IN1 | MOTOR_IN2) , 0x00 ); //Stop motor
	vTaskDelay (100/portTICK_RATE_MS);
	automaticControlDisabled = 0;
	}
}

//================================================= Init Function ====================================================================
void initGpio (void) //Init all pins to be used in the project as well as the interrupts.
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF); //Enable Clock
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF)); //Wait for peripheral to be ready.
	GPIOUnlockPin(CONTROL_PORT  ,  OBSTACLE_SWITCH | LOCK_TOGGLE); //Unlock Pins
	GPIOPinTypeGPIOInput(CONTROL_PORT , OBSTACLE_SWITCH | LOCK_TOGGLE); //Set Input pins
	GPIOPadConfigSet(CONTROL_PORT , ( OBSTACLE_SWITCH | LOCK_TOGGLE ) ,GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU); //Set input pin as pull up.
	
	GPIOIntRegister(CONTROL_PORT  ,lockControl_ISR); //Set interrupt and ISR.
	IntPrioritySet( INT_GPIOF_TM4C123 , 0x50); //Set interrupt priority.
	GPIOIntEnable(CONTROL_PORT , ( OBSTACLE_SWITCH | LOCK_TOGGLE  )); //Enable interrupt.
	GPIOIntTypeSet(CONTROL_PORT ,( OBSTACLE_SWITCH | LOCK_TOGGLE ),GPIO_FALLING_EDGE); //Set the Edge triggering the interrupt.
	
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD); //Enable Clock
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOD)); //Wait for peripheral to be ready.
	GPIOUnlockPin(MOTOR_PORT  ,  MOTOR_IN1 | MOTOR_IN2); //Unlock Pins
	GPIOPinTypeGPIOOutput(MOTOR_PORT , MOTOR_IN1 | MOTOR_IN2); //Set opt pins
	GPIOPinWrite(MOTOR_PORT,(MOTOR_IN1 | MOTOR_IN2), 0x00 ); //Write on pins the initial value 0.
	
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE); //Enable Clock.
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE)); //Wait for peripheral to be ready.
	GPIOUnlockPin(LIMIT_PORT  ,  LIMIT_UP | LIMIT_DOWN); //Unlock pins.
	GPIOPinTypeGPIOInput(LIMIT_PORT , LIMIT_UP | LIMIT_DOWN); //Set pins as input.
	GPIOPadConfigSet(LIMIT_PORT , ( LIMIT_UP | LIMIT_DOWN ) ,GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU); //Set input pin as pull up.

	GPIOIntRegister(LIMIT_PORT ,limitSwitch_ISR); //Set interrupt and ISR.
	IntPrioritySet( INT_GPIOE_TM4C123 , 0xD0); //Set interrupt priority.
	GPIOIntEnable(LIMIT_PORT , ( LIMIT_UP | LIMIT_DOWN )); //Enable interrupt
	GPIOIntTypeSet(LIMIT_PORT ,( LIMIT_UP | LIMIT_DOWN ),GPIO_FALLING_EDGE); //Set the Edge triggering the interrupt.

	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB); //Enable Clock
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB)); //Wait for peripheral to be ready.
	GPIOUnlockPin(DRIVER_PORT  ,  DRIVER_UP | DRIVER_DOWN); //Unlock pins.
	GPIOPinTypeGPIOInput(DRIVER_PORT , DRIVER_UP | DRIVER_DOWN); //Set pins as input.
	GPIOPadConfigSet(DRIVER_PORT , ( DRIVER_UP | DRIVER_DOWN ) ,GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU); //Set input pin as pull up.

	GPIOIntRegister(DRIVER_PORT ,driverSide_ISR); //Set interrupt and ISR.
	IntPrioritySet( INT_GPIOB_TM4C123 , 0xE0); //Set interrupt priority.
	GPIOIntEnable(DRIVER_PORT , ( DRIVER_UP | DRIVER_DOWN )); //Enable interrupt
	GPIOIntTypeSet(DRIVER_PORT ,( DRIVER_UP | DRIVER_DOWN ),GPIO_FALLING_EDGE); //Set the Edge triggering the interrupt.

	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA); //Enable Clock
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA)); //Wait for peripheral to be ready.
	GPIOUnlockPin(PASSENGER_PORT  ,  PASSENGER_UP | PASSENGER_DOWN); //Unlock pins.
	GPIOPinTypeGPIOInput(PASSENGER_PORT , PASSENGER_UP | PASSENGER_DOWN); //Set pins as input.
	GPIOPadConfigSet(PASSENGER_PORT , ( PASSENGER_UP | PASSENGER_DOWN ) ,GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU); //Set input pin as pull up.

	GPIOIntRegister(PASSENGER_PORT ,passengerSide_ISR); //Set interrupt and ISR.
	IntPrioritySet( INT_GPIOA_TM4C123 , 0xE0); //Set interrupt priority.
	GPIOIntEnable(PASSENGER_PORT , ( PASSENGER_UP | PASSENGER_DOWN )); //GPIOIntEnable(GPIO_PORTA_BASE , GPIO_INT_PIN_5 | GPIO_INT_PIN_6 | GPIO_INT_PIN_7); leeeh INT
	GPIOIntTypeSet(PASSENGER_PORT ,( PASSENGER_UP | PASSENGER_DOWN ),GPIO_FALLING_EDGE); //Set the Edge triggering the interrupt.
}


//====================================================================== Idle Task =====================================================
void vApplicationIdleHook( void ) //Idle Task Does nothing but sleep the ECU incase of no interrupts.
{
	__WFI(); //Sleep the ECU until an interrupt is recieved.
}
